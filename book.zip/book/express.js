// imports
import express from "express";
import bodyParser from "body-parser";

// constants
const app = express();
const port = 8080
const current_date = new Date();

// create the empty array
var bookLibrary = [];

// setting up the ejs and url
app.set('view engine', 'ejs');
app.use(express.static('static'));
app.use(bodyParser.urlencoded({ extended: true }));

// HOMEPAGE APP 

// deal with blog posts
app.get('/', (req, res) => 
{
    // access html script
    res.render('index.ejs', { bookLibrary });
});

// add a new post to the array
app.post('/create-form', (req, res) => 
{
    // put each of the variables into the array
    var newPost = { 
        title: req.body.title, content: req.body.content, 
        name: req.body.name, creationTime: current_date };
        
    // add the new post to the next array
    bookLibrary[bookLibrary.length] = newPost;

    // redirect back to homepage
    res.redirect('/');
});

// EDIT APP
// render the edit pages for posts
app.get('/edit/:id', (req, res) => 
{
    // get the new elemets of the array
    var postId = req.params.id;

    // get the index of each blog post 
    var post = bookLibrary[postId];

    // get the information from the edit section of the html
    res.render('edit.ejs', { post, postId });
});

// update posts
app.post('/edit/:id', (req, res) => 
{
    // get the array
    var postId = req.params.id;

    // update the array with the new edits if any
    bookLibrary[postId] = 
    { 
        // update title or keep the old title
        title: req.body.title || bookLibrary[postId].title,
        content: req.body.content || bookLibrary[postId].content,
        name: req.body.name || bookLibrary[postId].name,
        creationTime: bookLibrary[postId].creationTime 
    };
    // redirect back to homepage
    res.redirect('/');
});

// DELETE APP 

app.post('/delete/:id', (req, res) => {
    const postId = req.params.id;

    // remove post and redirect
    delete bookLibrary[postId];
    res.redirect('/');

});

// start server at the port
app.listen(port, () => 
    {
        console.log(`Server is running on port ${port}.`);
    });

