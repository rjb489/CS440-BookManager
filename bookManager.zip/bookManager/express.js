import express from 'express';
import bodyParser from 'body-parser';
import multer from 'multer';
import path from 'path';

// constants
const app = express();
const port = 8080;

// Set up storage for uploaded files using multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // unique file name
    }
});

// Set up multer for handling file uploads
const upload = multer({ storage: storage });

// Create the empty array to hold books
var userProfile = null;
var bookLibrary = [];

// Setting up the ejs and url
app.set('view engine', 'ejs');
app.use('/static', express.static('static'));
app.use('/uploads', express.static('uploads')); 
app.use(bodyParser.urlencoded({ extended: true }));

// HOMEPAGE - Display all books
app.get('/', (req, res) => {
    res.render('index.ejs', { bookLibrary });
});

// CREATE FORM - Render form to create a new book
app.get('/create', (req, res) => {
    res.render('create.ejs');
});

// POST /create-form - Add a new post to the array
app.post('/create-form', upload.single('coverImage'), (req, res) => {
    console.log('Uploaded File:', req.file); // Check if file is uploaded successfully
    const { title, name, content } = req.body;
    const coverImage = req.file ? req.file.filename : null; // Get uploaded file name

    var newPost = {
        title: title,
        name: name,
        content: content,
        coverImage: coverImage, // Store the uploaded image filename
        creationTime: new Date().toLocaleString()
    };

    bookLibrary.push(newPost);

    res.redirect('/');
});

// VIEW - Render the details of a specific book
app.get('/view/:id', (req, res) => {
    const postId = parseInt(req.params.id, 10);
    const post = bookLibrary[postId];

    if (post) {
        res.render('view.ejs', { post });
    } else {
        res.status(404).send('Book not found');
    }
});

// EDIT FORM - Render the edit form for a specific book
app.get('/edit/:id', (req, res) => {
    const postId = parseInt(req.params.id, 10);
    const post = bookLibrary[postId];

    if (post) {
        res.render('edit.ejs', { post, postId });
    } else {
        res.status(404).send('Book not found');
    }
});

// POST /edit-form/:id - Update an existing book
app.post('/edit-form/:id', upload.single('coverImage'), (req, res) => {
    const postId = parseInt(req.params.id, 10);
    const { title, name, content } = req.body;
    const coverImage = req.file ? req.file.filename : bookLibrary[postId].coverImage; // Keep existing coverImage if none uploaded

    if (postId >= 0 && postId < bookLibrary.length) {
        // Update the post with the new or unchanged data
        bookLibrary[postId] = {
            title: title || bookLibrary[postId].title,
            name: name || bookLibrary[postId].name,
            content: content || bookLibrary[postId].content,
            coverImage: coverImage,
            creationTime: bookLibrary[postId].creationTime // Keep original creation time
        };
        res.redirect('/');
    } else {
        res.status(404).send('Book not found');
    }
});

// DELETE - Remove a post from the library
app.post('/delete/:id', (req, res) => {
    const postId = parseInt(req.params.id, 10);

    // Remove the post using splice
    if (postId >= 0 && postId < bookLibrary.length) {
        bookLibrary.splice(postId, 1);
    }

    res.redirect('/');
});

// Route to view the profile
app.get('/profile', (req, res) => {
    if (userProfile) {
        // If user has a profile, render the profile view with user data
        res.render('profile', { userProfile, bookCount: bookLibrary.length });
    } else {
        // If no profile exists, redirect to the create profile page
        res.redirect('/create-profile');
    }
});
app.get('/create-profile', (req, res) => {
    res.render('create-profile');  // Render the create-profile.ejs view
});

// Route to display the create profile page
app.post('/create-profile', (req, res) => {
    const { username, password } = req.body;

    // Save the profile details 
    userProfile = { username, password };

    // Redirect to the profile page after creation
    res.redirect('/profile'); 
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}.`);
});
