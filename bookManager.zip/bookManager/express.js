import express from 'express';
import bodyParser from 'body-parser';
import multer from 'multer';
import path from 'path';
import mongoose from 'mongoose';
import session from 'express-session';
import flash from 'express-flash';

// constants
const app = express();
const port = 8080;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/bookLibraryDB')
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Failed to connect to MongoDB', err));

// Define the schema for books
const bookSchema = new mongoose.Schema({
    title: String,
    name: String,
    content: String,
    coverImage: String,
    creationTime: String,
});

// Define the schema for user profiles
const userProfileSchema = new mongoose.Schema({
    username: String,
    password: String,
});

// Create models based on the schemas
const Book = mongoose.model('Book', bookSchema);
const UserProfile = mongoose.model('UserProfile', userProfileSchema);

// Set up storage for uploaded files using multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // unique file name
    }
});

// Set up multer for handling file uploads
const upload = multer({ storage: storage });

app.use(session({
    secret: 'your_secret_key', // Replace with a secure key
    resave: false,
    saveUninitialized: true
}));
app.use(flash());

// Setting up the ejs and url
app.set('view engine', 'ejs');
app.use('/static', express.static('static'));
app.use('/uploads', express.static('uploads')); 
app.use(bodyParser.urlencoded({ extended: true }));

// HOMEPAGE - Display all books
app.get('/', (req, res) => {
    Book.find()
        .then(books => res.render('index.ejs', { bookLibrary: books }))
        .catch(err => res.status(500).send('Error retrieving books'));
});

// CREATE FORM - Render form to create a new book
app.get('/create', (req, res) => {
    res.render('create.ejs');
});

// POST /create-form - Add a new book to the database
app.post('/create-form', upload.single('coverImage'), (req, res) => {
    const { title, name, content } = req.body;
    const coverImage = req.file ? req.file.filename : null;

    const newBook = new Book({
        title,
        name,
        content,
        coverImage,
        creationTime: new Date().toLocaleString(),
    });

    newBook.save()
        .then(() => res.redirect('/'))
        .catch(err => res.status(500).send('Error saving book'));
});

// VIEW - Render the details of a specific book
app.get('/view/:id', (req, res) => {
    const bookId = req.params.id;

    // Check if the id is a valid ObjectId
    if (!mongoose.Types.ObjectId.isValid(bookId)) {
        return res.status(400).send('Invalid book ID');
    }

    Book.findById(bookId)
        .then(book => {
            if (book) {
                res.render('view.ejs', { post: book });
            } else {
                res.status(404).send('Book not found');
            }
        })
        .catch(err => {
            console.error('Error retrieving book:', err);
            res.status(500).send('Error retrieving book');
        });
});

// EDIT FORM - Render the edit form for a specific book
app.get('/edit/:id', (req, res) => {
    Book.findById(req.params.id)
        .then(book => {
            if (book) {
                res.render('edit.ejs', { post: book, postId: req.params.id });
            } else {
                res.status(404).send('Book not found');
            }
        })
        .catch(err => res.status(500).send('Error retrieving book'));
});

// POST /edit-form/:id - Update an existing book
app.post('/edit-form/:id', upload.single('coverImage'), (req, res) => {
    const { title, name, content } = req.body;
    const coverImage = req.file ? req.file.filename : undefined;

    Book.findById(req.params.id)
        .then(book => {
            if (!book) {
                return res.status(404).send('Book not found');
            }

            // Update book fields
            book.title = title || book.title;
            book.name = name || book.name;
            book.content = content || book.content;
            if (coverImage) book.coverImage = coverImage;

            return book.save();
        })
        .then(() => res.redirect('/'))
        .catch(err => res.status(500).send('Error updating book'));
});

// DELETE - Remove a book from the database
app.post('/delete/:id', (req, res) => {
    const bookId = req.params.id;

    // Validate the ObjectId
    if (!mongoose.Types.ObjectId.isValid(bookId)) {
        return res.status(400).send('Invalid book ID');
    }

    // Use the MongoDB _id to delete the book
    Book.findByIdAndDelete(bookId)
        .then(() => res.redirect('/'))
        .catch(err => res.status(500).send('Error deleting book'));
});

// Route to view the profile
app.get('/profile', async (req, res) => {
    try {
        const userProfile = await UserProfile.findOne(); // Assuming a single user profile in your app
        const bookCount = await Book.countDocuments({}); // Get the total count of books
        
        if (userProfile) {
            // Render profile view with user data and total book count
            res.render('profile', { userProfile, bookCount });
        } else {
            // If no profile exists, redirect to the create profile page
            res.redirect('/create-profile');
        }
    } catch (err) {
        res.status(500).send('Error retrieving profile or book count');
    }
});

// Route to display the create profile page
app.get('/create-profile', (req, res) => {
    res.render('create-profile');
});

// Route to create a user profile
app.post('/create-profile', (req, res) => {
    const { username, password } = req.body;

    const newUserProfile = new UserProfile({
        username,
        password,
    });

    newUserProfile.save()
        .then(() => res.redirect('/profile'))
        .catch(err => res.status(500).send('Error saving profile'));
});
app.get('/login', (req, res) => {
    res.render('login.ejs'); 
});

// POST /login - Handle login form submissions
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find user by username
        const userProfile = await UserProfile.findOne({ username });

        // If user is found and password matches
        if (userProfile && userProfile.password === password) {
            res.redirect('/profile'); // Redirect to profile page after successful login
        } else {
            // Flash error message and redirect back to login
            req.flash('error', 'Invalid username or password. Please try again.');
            res.redirect('/login'); // Redirect back to login
        }
    } catch (err) {
        res.status(500).send('Error logging in');
    }
});
// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}.`);
});
